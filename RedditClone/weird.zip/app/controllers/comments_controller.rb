class CommentsController < ApplicationController
end
